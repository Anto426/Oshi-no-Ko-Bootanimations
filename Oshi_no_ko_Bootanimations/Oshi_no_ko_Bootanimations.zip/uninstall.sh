  cp "/data/adb/modules/Oshi_no_ko_bootanimation-lite/backup/bootanimation.zip" "/product/media/" >/dev/null 2>&1
  rm -rf /data/system/package_cache/*
